# <img src='https://raw.githack.com/FortAwesome/Font-Awesome/master/svgs/solid/smile-wink.svg' card_color='#22a7f0' width='50' height='50' style='vertical-align:bottom'/> Mycroft's Background
Learn history and personality of Mycroft

## About
Ask about the "birth" and parentage of Mycroft and get a taste of the community
who is fostering this open source artificial intelligence.

## Examples
* "When were you created?"
* "What are you?"
* "Where were you born?"
* "Who made you?"
* "Do you even rhyme?"

## Credits
Mycroft AI (@MycroftAI)

Poem penned by community member Jelmer Prins

## Category
**Entertainment**

## Tags
#personality
#persona
